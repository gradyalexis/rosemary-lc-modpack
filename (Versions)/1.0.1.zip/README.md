# ROSEMARY MOD PACK

This mod includes:
- BepInEx
- MoreCompany
- LateCompany
- TooManyEmotes
- Mimics
- RollingGiant
- Scopophobia
- PushCompany